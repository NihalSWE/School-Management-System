from django.http import JsonResponse
from .models import *
import json  
from django.views.decorators.csrf import csrf_exempt  
from django.contrib.auth.hashers import make_password  

# --- This is your existing view ---
def get_designations(request):
    """
    This view will get all objects from the Designations table
    and return them as a JSON list.
    """
    data = Designations.objects.all()
    payload = list(data.values())
    return JsonResponse(payload, safe=False)


# --- This is your new view ---
@csrf_exempt
def user_list_create(request):
    """
    Handles GET and POST requests for the Users model.
    - GET: Returns a list of all users.
    - POST: Creates a new user.
    """

    # --- LIST USERS (GET) ---
    if request.method == 'GET':
        try:
            users = Users.objects.all()
            
            # --- THIS IS THE PART YOU CHANGED ---
            # We list all fields from the model,
            # but EXCLUDE 'password' and 'remember_token' for security.
            payload = list(users.values(
                'id',
                'usertype',
                'name',
                'email',
                'email_verified_at',
                'mobile',
                'address',
                'gender',
                'image',
                'fname',
                'mname',
                'religion',
                'id_no',
                'dob',
                'code',
                'role',
                'join_date',
                'designation_id',
                'salary',
                'status',
                'created_at',
                'updated_at'
            ))
            # --- END OF CHANGE ---

            return JsonResponse(payload, safe=False)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    # --- ADD USER (POST) ---
    elif request.method == 'POST':
        try:
            # 1. Load the data from the request body
            data = json.loads(request.body)

            # 2. Get the password from the data
            password = data.get('password')
            if not password:
                return JsonResponse({'error': 'Password is required'}, status=400)

            # 3. Create the new user
            new_user = Users.objects.create(
                name=data.get('name'),
                email=data.get('email'),
                usertype=data.get('usertype', 'student'), # Default to 'student'
                status=data.get('status', 1), # Default to 'active'
                mobile=data.get('mobile'),
                address=data.get('address'),
                # Add any other fields you want to set from the POST
                gender=data.get('gender'),
                fname=data.get('fname'),
                mname=data.get('mname'),
                religion=data.get('religion'),
                id_no=data.get('id_no'),
                dob=data.get('dob'),
                join_date=data.get('join_date'),
                salary=data.get('salary'),
                
                # 4. CRITICAL: Hash the password before saving
                password=make_password(password)
            )

            # 5. Return a success message
            response_data = {
                'message': 'User created successfully',
                'user_id': new_user.id,
                'name': new_user.name
            }
            return JsonResponse(response_data, status=201) # 201 means "Created"

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            # Handle other potential errors, e.g., if email must be unique
            return JsonResponse({'error': f'Could not create user: {str(e)}'}, status=500)

    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    
    
@csrf_exempt
def user_detail_update_delete(request, pk):
    """
    Handles GET, PUT, and DELETE requests for a *single* user.
    'pk' is the id of the user, passed from the URL.
    """
    
    # 1. First, try to find the user.
    try:
        user = Users.objects.get(id=pk)
    except Users.DoesNotExist:
        return JsonResponse({'error': 'User not found'}, status=404)


    # --- GET A SINGLE USER ---
    if request.method == 'GET':
        try:
            payload = Users.objects.filter(id=pk).values(
                'id', 'usertype', 'name', 'email', 'email_verified_at',
                'mobile', 'address', 'gender', 'image', 'fname', 'mname',
                'religion', 'id_no', 'dob', 'code', 'role', 'join_date',
                'designation_id', 'salary', 'status', 'created_at', 'updated_at'
            ).first() 
            
            if payload:
                return JsonResponse(payload, safe=False)
            else:
                return JsonResponse({'error': 'User not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    # --- UPDATE A USER (PUT) ---
    elif request.method == 'PUT':
        try:
            data = json.loads(request.body)
            
            # --- THIS IS THE UPDATED SECTION ---
            # Update all fields from the data, using current value as default
            user.name = data.get('name', user.name)
            user.email = data.get('email', user.email)
            user.usertype = data.get('usertype', user.usertype)
            user.status = data.get('status', user.status)
            user.mobile = data.get('mobile', user.mobile)
            user.address = data.get('address', user.address)
            user.gender = data.get('gender', user.gender)
            user.image = data.get('image', user.image)
            user.fname = data.get('fname', user.fname)
            user.mname = data.get('mname', user.mname)
            user.religion = data.get('religion', user.religion)
            user.id_no = data.get('id_no', user.id_no)
            user.dob = data.get('dob', user.dob)
            user.code = data.get('code', user.code)
            user.role = data.get('role', user.role)
            user.join_date = data.get('join_date', user.join_date)
            user.designation_id = data.get('designation_id', user.designation_id)
            user.salary = data.get('salary', user.salary)
            # --- END OF UPDATED SECTION ---

            # We don't update 'id', 'created_at', or 'updated_at' manually.
            
            # CRITICAL: If a new password was sent, hash it
            if 'password' in data and data['password']:
                user.password = make_password(data['password'])
            
            user.save() # Save the changes to the database
            
            return JsonResponse({'message': 'User updated successfully!'})
        
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            return JsonResponse({'error': f'Could not update user: {str(e)}'}, status=500)

    # --- DELETE A USER ---
    elif request.method == 'DELETE':
        try:
            user.delete()
            return JsonResponse({'message': 'User deleted successfully'}, status=200)
        except Exception as e:
            return JsonResponse({'error': f'Could not delete user: {str(e)}'}, status=500)

    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)