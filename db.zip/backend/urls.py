# In backend/urls.py (the new file you just created)

from django.urls import path
from . import views  # This imports your views.py file

urlpatterns = [
    # This says: when someone visits 'designations/',
    # run the 'get_designations' view.
    path('designations/', views.get_designations, name='get-designations'),
    path('users/', views.user_list_create, name='user-list-create'),
    path('users/<int:pk>/', views.user_detail_update_delete, name='user-detail'),
]